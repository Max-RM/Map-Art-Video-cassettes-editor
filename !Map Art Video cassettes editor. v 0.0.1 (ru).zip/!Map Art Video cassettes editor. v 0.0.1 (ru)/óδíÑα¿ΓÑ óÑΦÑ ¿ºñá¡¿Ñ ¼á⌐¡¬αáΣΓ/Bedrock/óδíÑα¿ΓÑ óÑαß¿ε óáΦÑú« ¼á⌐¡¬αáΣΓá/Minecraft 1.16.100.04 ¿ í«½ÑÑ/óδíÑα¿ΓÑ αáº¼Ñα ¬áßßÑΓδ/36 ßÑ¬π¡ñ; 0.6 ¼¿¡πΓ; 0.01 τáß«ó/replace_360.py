import re
 
t = int(input())
with open('360.txt', 'r') as infe, open('out_360.txt', 'w') as f:
    f.write(re.sub(r'(?i)(6964)([a-f0-9]{16})(000005)',
                   lambda x: f'{x.group(1)}{hex(int(x.group(2), 16) + t)[2:].zfill(16)}'
                             f'{x.group(3)}', infe.read()))
